-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2020 at 08:14 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socialnetwork`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_body` text NOT NULL,
  `posted_by` varchar(60) NOT NULL,
  `posted_to` varchar(60) NOT NULL,
  `date_added` datetime NOT NULL,
  `removed` varchar(3) NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_body`, `posted_by`, `posted_to`, `date_added`, `removed`, `post_id`) VALUES
(38, 'hello', 'sandesh_thapa_1', 'john_doe', '2020-04-20 13:09:27', 'no', 3),
(39, 'hey there', 'sandesh_thapa_1', 'john_doe', '2020-04-20 13:10:41', 'no', 3),
(40, 'good job mate', 'john_doe', 'sandesh_thapa_1', '2020-04-20 13:11:24', 'no', 15),
(41, 'Great going', 'john_doe', 'john_doe', '2020-04-20 13:17:55', 'no', 13),
(42, 'hey man', 'john_doe', 'sandesh_thapa_1', '2020-04-20 13:19:15', 'no', 11),
(43, 'ajax not working', 'john_doe', 'sandesh_thapa_1', '2020-04-20 13:20:31', 'no', 24),
(44, 'nope', 'john_doe', 'john_doe', '2020-04-20 13:20:46', 'no', 22),
(45, 'sad', 'john_doe', 'sandesh_thapa_1', '2020-04-20 13:23:15', 'no', 24),
(46, 'ok man', 'john_doe', 'sandesh_thapa_1', '2020-04-20 13:53:46', 'no', 23),
(47, 'not working man', 'john_doe', 'sandesh_thapa_1', '2020-04-20 13:55:39', 'no', 24),
(48, 'test comment', 'john_doe', 'john_doe', '0000-00-00 00:00:00', 'no', 12),
(49, 'And john is replying', 'john_doe', 'john_doe', '2020-04-20 14:01:57', 'no', 9),
(50, 'exahusted', 'john_doe', 'sandesh_thapa_1', '2020-04-20 14:10:03', 'no', 24),
(51, 'but ajax is not working', 'john_doe', '', '2020-04-20 14:13:21', 'no', 15),
(52, 'ajax is not working', 'john_doe', '', '2020-04-20 14:13:59', 'no', 21),
(53, 'but ajax is not working properly', 'john_doe', 'john_doe', '2020-04-20 14:15:39', 'no', 13),
(55, 'hey', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 05:50:58', 'no', 24),
(56, 'good', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 05:51:09', 'no', 21),
(57, 'again for 24', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 05:51:57', 'no', 24),
(58, 'hey', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 06:11:52', 'no', 24),
(59, '123123drink', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 06:14:24', 'no', 24),
(60, 'Oh my god ajax posting comment is really working!!!', 'sandesh_thapa_1', 'john_doe', '2020-04-21 06:16:10', 'no', 22),
(61, 'Really man its working', 'john_doe', 'sandesh_thapa_1', '2020-04-21 06:19:02', 'no', 24),
(62, 'Yay Yay!!!', 'john_doe', 'john_doe', '2020-04-21 06:33:25', 'no', 13),
(63, 'Its getting interesting', 'john_doe', 'sandesh_thapa_1', '2020-04-21 06:43:26', 'no', 23),
(64, 'Its getting Intresting', 'john_doe', 'sandesh_thapa_1', '2020-04-21 06:44:51', 'no', 15),
(65, 'hello man', 'john_doe', 'sandesh_thapa_1', '2020-04-21 06:46:19', 'no', 11),
(66, 'comment frame 12', 'sandesh_thapa_1', 'john_doe', '2020-04-21 09:04:16', 'no', 12),
(67, 'comment frame 24', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 09:06:50', 'no', 24),
(68, 'Wow! I think ajax is working ', 'sandesh_thapa_1', 'john_doe', '2020-04-21 09:08:01', 'no', 16),
(69, 'wow', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 09:12:05', 'no', 24),
(70, 'Hello John', 'sandesh_thapa_1', 'john_doe', '2020-04-21 09:12:52', 'no', 10),
(71, 'Great Its working', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 09:15:55', 'no', 21),
(72, 'try once', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 09:32:40', 'no', 24),
(73, 'timout check', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 09:35:01', 'no', 24),
(74, 'timout check', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 09:35:06', 'no', 24),
(75, 'check setTimeout function', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 09:36:14', 'no', 24),
(76, 'checking reset function', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 09:39:26', 'no', 24),
(77, 'not working', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 09:40:12', 'no', 24),
(78, 'Be optimistic', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 09:42:00', 'no', 24),
(79, 'why clearing text not working??', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 09:43:19', 'no', 24),
(80, 'wow clearing text box works', 'sandesh_thapa_1', 'john_doe', '2020-04-21 09:43:40', 'no', 22),
(81, 'its working man', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-04-21 09:44:41', 'no', 21),
(82, 'A long comment ........................ sdfsdfsdfdssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss........................fds.sd.f.dsf.dsf.sdf ', 'john_doe', 'sandesh_thapa_1', '2020-04-21 11:24:16', 'no', 24),
(83, 'great going buddy', 'john_doe', 'sandesh_thapa_1', '2020-04-25 13:39:03', 'no', 39),
(84, 'test comment for notification', 'sandesh_thapa_1', 'jean_doe', '2020-05-20 11:54:48', 'no', 19),
(85, 'comment', 'sandesh_thapa_1', 'john_doe', '2020-05-20 11:59:49', 'no', 30),
(86, 'comment notification check ', 'jean_doe', 'sandesh_thapa_1', '2020-05-20 12:26:42', 'no', 24),
(87, 'sadasd', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-05-21 09:48:56', 'no', 47),
(88, 'test comment', 'sandesh_thapa_1', 'sandesh_thapa_1', '2020-06-07 15:13:18', 'no', 51);

-- --------------------------------------------------------

--
-- Table structure for table `friend_requests`
--

CREATE TABLE `friend_requests` (
  `id` int(11) NOT NULL,
  `user_to` varchar(50) NOT NULL,
  `user_from` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friend_requests`
--

INSERT INTO `friend_requests` (`id`, `user_to`, `user_from`) VALUES
(1, 'jean_doe', 'nidan_shrestha');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `username` varchar(60) NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `username`, `post_id`) VALUES
(2, 'sandesh_thapa_1', 21),
(5, 'john_doe', 23),
(6, 'sandesh_thapa_1', 23),
(9, 'john_doe', 24),
(14, 'sandesh_thapa_1', 22),
(19, 'sandesh_thapa_1', 17),
(20, 'sandesh_thapa_1', 24),
(22, 'sandesh_thapa_1', 16),
(24, 'jean_doe', 25),
(25, 'jean_doe', 24),
(27, 'john_doe', 11),
(29, 'sandesh_thapa_1', 20),
(30, 'jean_doe', 20),
(31, 'sandesh_thapa_1', 33),
(34, 'john_doe', 12),
(35, 'john_doe', 43),
(37, 'sandesh_thapa_1', 1),
(39, 'sandesh_thapa_1', 30),
(41, 'sandesh_thapa_1', 35),
(42, 'jean_doe', 32),
(43, 'sandesh_thapa_1', 45),
(44, 'sandesh_thapa_1', 44),
(45, 'sandesh_thapa_1', 46),
(46, 'sandesh_thapa_1', 47),
(49, 'sandesh_thapa_1', 29),
(50, 'sandesh_thapa_1', 19),
(52, 'sandesh_thapa_1', 48),
(53, 'sandesh_thapa_1', 51);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `user_to` varchar(50) NOT NULL,
  `user_from` varchar(50) NOT NULL,
  `body` text NOT NULL,
  `date` datetime NOT NULL,
  `opened` varchar(3) NOT NULL,
  `viewed` varchar(3) NOT NULL,
  `deleted` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `user_to`, `user_from`, `body`, `date`, `opened`, `viewed`, `deleted`) VALUES
(1, 'john_doe', 'sandesh_thapa_1', 'Hello John', '2020-05-10 11:42:47', 'yes', 'yes', 'no'),
(2, 'john_doe', 'sandesh_thapa_1', 'Checking Messages', '2020-05-10 11:43:57', 'yes', 'yes', 'no'),
(3, 'john_doe', 'sandesh_thapa_1', 'check for reset textbox', '2020-05-10 11:45:26', 'yes', 'yes', 'no'),
(4, 'john_doe', 'sandesh_thapa_1', 'check for response text ajax', '2020-05-10 11:48:47', 'yes', 'yes', 'no'),
(5, 'sandesh_thapa_1', 'john_doe', 'Hey Sandesh.. Whst\'s up?', '2020-05-10 11:52:29', 'yes', 'yes', 'no'),
(6, 'sandesh_thapa_1', 'john_doe', 'Message from john to sandesh', '2020-05-10 11:53:07', 'yes', 'yes', 'no'),
(7, 'john_doe', 'sandesh_thapa_1', 'Hello John', '2020-05-11 05:32:45', 'yes', 'yes', 'no'),
(8, 'john_doe', 'sandesh_thapa_1', 'How are you?', '2020-05-11 05:32:57', 'yes', 'yes', 'no'),
(9, 'sandesh_thapa_1', 'john_doe', 'Hi Sandesh', '2020-05-11 05:34:58', 'yes', 'yes', 'no'),
(10, 'sandesh_thapa_1', 'john_doe', 'im good', '2020-05-11 05:35:08', 'yes', 'yes', 'no'),
(11, 'sandesh_thapa_1', 'john_doe', 'What about you?', '2020-05-11 05:35:18', 'yes', 'yes', 'no'),
(12, 'sandesh_thapa_1', 'john_doe', 'Im great', '2020-05-11 06:29:23', 'yes', 'yes', 'no'),
(13, 'sandesh_thapa_1', 'john_doe', 'great ajax working perfectly', '2020-05-11 06:30:14', 'yes', 'yes', 'no'),
(14, 'sandesh_thapa_1', 'john_doe', 'check message', '2020-05-11 06:37:18', 'yes', 'yes', 'no'),
(15, 'sandesh_thapa_1', 'john_doe', '123123', '2020-05-11 06:45:08', 'yes', 'yes', 'no'),
(16, 'sandesh_thapa_1', 'john_doe', 'asdasdasd', '2020-05-11 06:45:30', 'yes', 'yes', 'no'),
(17, 'sandesh_thapa_1', 'john_doe', 'ajax display message not working', '2020-05-11 06:46:51', 'yes', 'yes', 'no'),
(18, 'john_doe', 'sandesh_thapa_1', 'try again', '2020-05-11 10:24:32', 'yes', 'yes', 'no'),
(19, 'john_doe', 'sandesh_thapa_1', 'asdasdasdasd', '2020-05-11 10:45:23', 'yes', 'yes', 'no'),
(20, 'john_doe', 'sandesh_thapa_1', 'yeah its working man', '2020-05-11 10:45:39', 'yes', 'yes', 'no'),
(21, 'sandesh_thapa_1', 'john_doe', 'finally its working (;-0', '2020-05-11 10:47:59', 'yes', 'yes', 'no'),
(22, 'sandesh_thapa_1', 'john_doe', 'hehe', '2020-05-11 11:09:31', 'yes', 'yes', 'no'),
(23, 'sandesh_thapa_1', 'john_doe', 'hello sandesh now test for profile pic', '2020-05-11 11:13:01', 'yes', 'yes', 'no'),
(24, 'john_doe', 'sandesh_thapa_1', 'Yeah dude its working fine', '2020-05-11 11:36:23', 'yes', 'yes', 'no'),
(25, 'john_doe', 'sandesh_thapa_1', 'hehe', '2020-05-11 11:42:27', 'yes', 'yes', 'no'),
(26, 'john_doe', 'sandesh_thapa_1', 'scroll bottom functionality', '2020-05-11 11:45:11', 'yes', 'yes', 'no'),
(27, 'john_doe', 'sandesh_thapa_1', 'sdfsdf asddas dasdasddddddddddddddddddddddddddddddddddd asddddddddddddddddddddddddddddddddddddddddddd adssssssssssssssssssssssssss', '2020-05-11 11:48:04', 'yes', 'yes', 'no'),
(28, 'john_doe', 'sandesh_thapa_1', 'asdasd asdasdasd', '2020-05-11 11:48:49', 'yes', 'yes', 'no'),
(29, 'john_doe', 'sandesh_thapa_1', 'ad asdasdasd asd', '2020-05-11 12:03:40', 'yes', 'yes', 'no'),
(30, 'john_doe', 'sandesh_thapa_1', 'asdasdasd', '2020-05-11 12:04:19', 'yes', 'yes', 'no'),
(31, 'john_doe', 'sandesh_thapa_1', 'asdasd', '2020-05-11 12:04:24', 'yes', 'yes', 'no'),
(32, 'john_doe', 'sandesh_thapa_1', 'asdasdasd', '2020-05-11 12:04:27', 'yes', 'yes', 'no'),
(33, 'john_doe', 'sandesh_thapa_1', 'asdasdasd', '2020-05-11 12:04:36', 'yes', 'yes', 'no'),
(34, 'john_doe', 'sandesh_thapa_1', 'asdasd', '2020-05-11 12:04:40', 'yes', 'yes', 'no'),
(35, 'john_doe', 'sandesh_thapa_1', 'asdasd', '2020-05-11 12:04:44', 'yes', 'yes', 'no'),
(36, 'sandesh_thapa_1', 'john_doe', 'adsa asdasdas', '2020-05-11 12:12:35', 'yes', 'yes', 'no'),
(37, 'sandesh_thapa_1', 'john_doe', ' long message check ........................ asdsdasdasdashduasifhioywsdgiady aidsy gioydgiad ioad hfgio dtgioa diog aida dai ygioady giodhvia8erg ioads goa8rtgioadgiadgiadigaydgadsijgyaodsgioaditgad gioa ad  aid gyuioadygioa aid oiadygioad goia g', '2020-05-11 12:13:02', 'yes', 'yes', 'no'),
(38, 'sandesh_thapa_1', 'john_doe', 'asdasd', '2020-05-11 12:30:25', 'yes', 'yes', 'no'),
(39, 'sandesh_thapa_1', 'john_doe', 'asdasd', '2020-05-11 12:30:26', 'yes', 'yes', 'no'),
(40, 'sandesh_thapa_1', 'john_doe', 'asdasda', '2020-05-11 12:30:48', 'yes', 'yes', 'no'),
(41, 'sandesh_thapa_1', 'john_doe', 'asdasdasdasdas', '2020-05-11 12:30:50', 'yes', 'yes', 'no'),
(42, 'sandesh_thapa_1', 'john_doe', 'sandeshasfaiofyhoia sada f', '2020-05-11 12:30:58', 'yes', 'yes', 'no'),
(43, 'sandesh_thapa_1', 'john_doe', 'asdasdasdas', '2020-05-11 12:31:22', 'yes', 'yes', 'no'),
(44, 'sandesh_thapa_1', 'john_doe', 'asdasdas', '2020-05-11 12:32:15', 'yes', 'yes', 'no'),
(45, 'sandesh_thapa_1', 'john_doe', 'asdasdasd', '2020-05-11 12:32:17', 'yes', 'yes', 'no'),
(46, 'sandesh_thapa_1', 'john_doe', 'hey man', '2020-05-11 12:32:27', 'yes', 'yes', 'no'),
(47, 'sandesh_thapa_1', 'john_doe', 'adsasdas', '2020-05-11 12:34:26', 'yes', 'yes', 'no'),
(48, 'sandesh_thapa_1', 'john_doe', 'asdasdasdas', '2020-05-11 12:37:52', 'yes', 'yes', 'no'),
(49, 'sandesh_thapa_1', 'john_doe', '1111111111112222222222222222222233333333333333333', '2020-05-11 12:38:03', 'yes', 'yes', 'no'),
(50, 'sandesh_thapa_1', 'john_doe', 'asjdioasdh', '2020-05-11 12:41:13', 'yes', 'yes', 'no'),
(51, 'sandesh_thapa_1', 'john_doe', 'adfasdf', '2020-05-11 12:41:19', 'yes', 'yes', 'no'),
(52, 'sandesh_thapa_1', 'john_doe', 'asdasd', '2020-05-11 12:46:52', 'yes', 'yes', 'no'),
(53, 'john_doe', 'sandesh_thapa_1', 'Live Message Test', '2020-05-12 10:04:00', 'yes', 'yes', 'no'),
(54, 'sandesh_thapa_1', 'john_doe', 'yeah its working, live message', '2020-05-12 10:04:20', 'yes', 'yes', 'no'),
(55, 'john_doe', 'sandesh_thapa_1', 'zxcxzc', '2020-05-12 11:29:44', 'yes', 'yes', 'no'),
(56, 'john_doe', 'sandesh_thapa_1', 'asd', '2020-05-12 11:54:04', 'yes', 'yes', 'no'),
(57, 'john_doe', 'sandesh_thapa_1', 'asdasd', '2020-05-12 11:54:08', 'yes', 'yes', 'no'),
(58, 'john_doe', 'sandesh_thapa_1', 'asdasd', '2020-05-12 12:42:26', 'yes', 'yes', 'no'),
(59, 'john_doe', 'sandesh_thapa_1', 'asdasd', '2020-05-12 12:42:32', 'yes', 'yes', 'no'),
(60, 'john_doe', 'sandesh_thapa_1', 'sdfdsf', '2020-05-12 12:43:49', 'yes', 'yes', 'no'),
(61, 'john_doe', 'sandesh_thapa_1', 'asdasd', '2020-05-12 12:48:31', 'yes', 'yes', 'no'),
(62, 'john_doe', 'sandesh_thapa_1', 'asdasdasd', '2020-05-12 12:48:46', 'yes', 'yes', 'no'),
(63, 'john_doe', 'sandesh_thapa_1', 'asdasd', '2020-05-12 12:49:25', 'yes', 'yes', 'no'),
(64, 'john_doe', 'sandesh_thapa_1', 'asdasd', '2020-05-12 12:49:34', 'yes', 'yes', 'no'),
(65, 'jean_doe', 'sandesh_thapa_1', 'Hello Jean', '2020-05-13 11:10:09', 'yes', 'yes', 'no'),
(66, 'sandesh_thapa_1', 'jean_doe', 'Hi Sandesh', '2020-05-13 11:11:27', 'yes', 'yes', 'no'),
(67, 'john_doe', 'sandesh_thapa_1', 'Checking Ajax display chat list with long textttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt', '2020-05-13 11:48:45', 'yes', 'yes', 'no'),
(68, 'jean_doe', 'sandesh_thapa_1', 'Test message', '2020-05-13 11:50:25', 'yes', 'yes', 'no'),
(69, 'jean_doe', 'sandesh_thapa_1', 'test message dropdown', '2020-05-18 09:57:35', 'yes', 'yes', 'no'),
(70, 'sandesh_thapa_1', 'jean_doe', '123', '2020-05-18 09:59:18', 'yes', 'yes', 'no'),
(71, 'jean_doe', 'sandesh_thapa_1', 'aasd', '2020-05-18 10:07:36', 'yes', 'yes', 'no'),
(72, 'sandesh_thapa_1', 'meelan_khadka', 'Hello Sandesh', '2020-05-19 04:42:21', 'yes', 'yes', 'no'),
(73, 'manish_khadka', 'sandesh_thapa_1', 'Hello manish', '2020-05-19 04:57:12', 'yes', 'yes', 'no'),
(74, 'sandesh_thapa_1', 'manish_khadka', 'hi', '2020-05-19 04:57:47', 'yes', 'yes', 'no'),
(75, 'sandesh_thapa_1', 'nidan_shrestha', 'Hey man', '2020-05-19 05:04:28', 'yes', 'yes', 'no'),
(76, 'nidan_shrestha', 'sandesh_thapa_1', 'hello nidan ', '2020-05-19 05:33:41', 'no', 'yes', 'no'),
(77, 'john_doe', 'sandesh_thapa_1', 'Now Notification badge check', '2020-05-19 06:11:41', 'yes', 'yes', 'no'),
(78, 'manish_khadka', 'sandesh_thapa_1', 'like', '2020-05-20 09:54:03', 'yes', 'yes', 'no'),
(79, 'manish_khadka', 'sandesh_thapa_1', 'thoplo (.)', '2020-05-20 10:02:48', 'yes', 'yes', 'no'),
(80, 'sandesh_thapa_1', 'manish_khadka', 'wow', '2020-05-20 10:33:37', 'yes', 'yes', 'no'),
(81, 'john_doe', 'sandesh_thapa_1', 'asdasd', '2020-05-21 07:57:05', 'no', 'yes', 'no'),
(82, 'meelan_khadka', 'sandesh_thapa_1', 'hi', '2020-06-07 15:19:28', 'yes', 'yes', 'no'),
(83, 'sandesh_thapa_1', 'meelan_khadka', 'asdasdasd', '2020-06-07 15:19:56', 'yes', 'yes', 'no'),
(84, 'meelan_khadka', 'sandesh_thapa_1', 'asdasdasd', '2020-06-07 15:20:06', 'yes', 'yes', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_to` varchar(50) NOT NULL,
  `user_from` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `link` varchar(100) NOT NULL,
  `datetime` datetime NOT NULL,
  `opened` varchar(3) NOT NULL,
  `viewed` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_to`, `user_from`, `message`, `link`, `datetime`, `opened`, `viewed`) VALUES
(1, 'john_doe', 'sandesh_thapa_1', 'Sandesh Thapa  posted on your profile', 'post.php?id=47', '2020-05-20 11:22:20', 'yes', 'yes'),
(2, '', 'sandesh_thapa_1', 'Sandesh Thapa  liked on your post', 'post.php?id=29', '2020-05-20 11:53:30', 'no', 'no'),
(3, '', 'sandesh_thapa_1', 'Sandesh Thapa  liked on your post', 'post.php?id=29', '2020-05-20 11:53:34', 'no', 'no'),
(4, '', 'sandesh_thapa_1', 'Sandesh Thapa  liked on your post', 'post.php?id=29', '2020-05-20 11:53:35', 'no', 'no'),
(5, 'jean_doe', 'sandesh_thapa_1', 'Sandesh Thapa  commented on your post', 'post.php?id=19', '2020-05-20 11:54:48', 'no', 'no'),
(6, 'john_doe', 'sandesh_thapa_1', 'Sandesh Thapa  commented on your post', 'post.php?id=30', '2020-05-20 11:59:49', 'yes', 'yes'),
(7, 'jean_doe', 'sandesh_thapa_1', 'Sandesh Thapa  liked on your post', 'post.php?id=19', '2020-05-20 12:25:03', 'no', 'no'),
(8, 'sandesh_thapa_1', 'jean_doe', 'Jean Simpson  commented on your post', 'post.php?id=24', '2020-05-20 12:26:42', 'no', 'yes'),
(9, 'john_doe', 'jean_doe', 'Jean Simpson  also comment on a post that you followed', 'post.php?id=24', '2020-05-20 12:26:42', 'no', 'yes'),
(10, 'john_doe', 'sandesh_thapa_1', 'Sandesh Thapa  commented on your profile post', 'post.php?id=47', '2020-05-21 09:48:56', 'yes', 'yes'),
(11, 'nidan_shrestha', 'sandesh_thapa_1', 'Sandesh Thapa  liked on your post', 'post.php?id=48', '2020-05-26 11:00:45', 'no', 'no'),
(12, 'nidan_shrestha', 'sandesh_thapa_1', 'Sandesh Thapa  liked on your post', 'post.php?id=48', '2020-05-26 11:00:49', 'no', 'no'),
(13, 'john_doe', 'sandesh_thapa_1', 'Sandesh Thapa  posted on your profile', 'post.php?id=51', '2020-05-29 06:42:41', 'no', 'no'),
(14, 'john_doe', 'sandesh_thapa_1', 'Sandesh Thapa  commented on your profile post', 'post.php?id=51', '2020-06-07 15:13:18', 'no', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `body` text NOT NULL,
  `added_by` varchar(60) NOT NULL,
  `user_to` varchar(60) NOT NULL,
  `date_added` datetime NOT NULL,
  `user_closed` varchar(3) NOT NULL,
  `deleted` varchar(3) NOT NULL,
  `likes` int(11) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `body`, `added_by`, `user_to`, `date_added`, `user_closed`, `deleted`, `likes`, `image`) VALUES
(1, 'This is the first post', 'sandesh_thapa_1', 'none', '2020-04-17 05:24:43', 'no', 'no', 1, ''),
(2, 'This is the first post', 'sandesh_thapa_1', 'none', '2020-04-17 05:30:04', 'no', 'no', 0, ''),
(3, 'Hello, everyone', 'john_doe', 'none', '2020-04-17 06:33:29', 'no', 'no', 0, ''),
(4, 'First post from Jean Doe\r\n', 'jean_doe', 'none', '2020-04-17 06:35:06', 'no', 'no', 0, ''),
(5, 'test,try,fun !!', 'sandesh_thapa_1', 'none', '2020-04-17 08:55:30', 'no', 'no', 0, ''),
(6, 'Test post from john Doe', 'john_doe', 'none', '2020-04-17 08:56:04', 'no', 'no', 0, ''),
(7, 'Hello, World !!! :)', 'jean_doe', 'none', '2020-04-17 08:57:29', 'no', 'no', 0, ''),
(8, 'Test Post from Sandesh', 'sandesh_thapa_1', 'none', '2020-04-17 10:02:05', 'no', 'no', 0, ''),
(9, 'hello everyone. It\'s John', 'john_doe', 'none', '2020-04-17 10:04:09', 'no', 'no', 0, ''),
(10, 'Another post from john', 'john_doe', 'none', '2020-04-17 10:04:37', 'no', 'no', 0, ''),
(11, 'Hey There!', 'sandesh_thapa_1', 'none', '2020-04-17 15:24:31', 'no', 'no', 1, ''),
(12, 'test for infinite scrolling....', 'john_doe', 'none', '2020-04-17 15:25:18', 'no', 'no', 1, ''),
(13, 'More Posts And Status', 'john_doe', 'none', '2020-04-17 15:25:29', 'no', 'no', 0, ''),
(14, 'Infinite Scrolling Not Working !!!!!', 'jean_doe', 'none', '2020-04-17 15:26:09', 'no', 'no', 0, ''),
(15, 'Infinite scroll seems to work', 'sandesh_thapa_1', 'none', '2020-04-18 04:05:15', 'no', 'no', 0, ''),
(16, 'Increase no of posts', 'john_doe', 'none', '2020-04-18 04:06:02', 'no', 'no', 1, ''),
(17, 'Another posts from john doe', 'john_doe', 'none', '2020-04-18 04:07:43', 'no', 'yes', 1, ''),
(18, 'Yeah just increase no of posts', 'jean_doe', 'none', '2020-04-18 04:08:22', 'no', 'no', 0, ''),
(19, 'Hello World', 'jean_doe', 'none', '2020-04-18 04:08:35', 'no', 'no', 1, ''),
(20, 'This post makes posts count to 20', 'jean_doe', 'none', '2020-04-18 04:09:12', 'no', 'no', 2, ''),
(21, 'now lets check infinite scrolling', 'sandesh_thapa_1', 'none', '2020-04-18 04:09:47', 'no', 'no', 1, ''),
(22, 'Seems Working yay!! :) :) :)', 'john_doe', 'none', '2020-04-18 04:17:35', 'no', 'yes', 1, ''),
(23, 'Just increasing no of posts', 'sandesh_thapa_1', 'none', '2020-04-18 04:18:44', 'no', 'no', 2, ''),
(24, 'One more time', 'sandesh_thapa_1', 'none', '2020-04-18 04:18:53', 'no', 'no', 3, ''),
(25, 'form another account Jean', 'jean_doe', 'none', '2020-04-18 04:19:21', 'no', 'no', 1, ''),
(29, 'Post From John to Jean', 'john_doe', 'jean_doe', '2020-04-24 16:29:01', 'no', 'no', 1, ''),
(30, 'Post from John to Sandesh', 'john_doe', 'sandesh_thapa_1', '2020-04-24 16:31:00', 'no', 'no', 1, ''),
(31, 'From Sandesh to Jean', 'sandesh_thapa_1', 'jean_doe', '2020-04-24 16:33:22', 'no', 'no', 0, ''),
(32, 'From Sandesh to Jean', 'sandesh_thapa_1', 'jean_doe', '2020-04-24 16:34:15', 'no', 'no', 1, ''),
(33, 'hey buddy, ', 'sandesh_thapa_1', 'john_doe', '2020-04-25 05:31:29', 'no', 'no', 1, ''),
(35, 'Not working properly', 'sandesh_thapa_1', 'john_doe', '2020-04-25 05:33:12', 'no', 'no', 1, ''),
(36, 'Not working properly', 'sandesh_thapa_1', 'john_doe', '2020-04-25 05:33:12', 'no', 'no', 0, ''),
(37, 'its not working', 'sandesh_thapa_1', 'john_doe', '2020-04-25 05:39:24', 'no', 'no', 0, ''),
(38, 'its not working', 'sandesh_thapa_1', 'john_doe', '2020-04-25 05:39:24', 'no', 'no', 0, ''),
(39, 'hope so', 'sandesh_thapa_1', 'john_doe', '2020-04-25 05:47:48', 'no', 'yes', 0, ''),
(40, 'Seems like its working', 'john_doe', 'sandesh_thapa_1', '2020-04-25 05:48:51', 'no', 'yes', 0, ''),
(41, 'yes it is', 'john_doe', 'sandesh_thapa_1', '2020-04-25 05:49:29', 'no', 'yes', 0, ''),
(42, 'once more', 'john_doe', 'sandesh_thapa_1', '2020-04-25 06:03:41', 'no', 'yes', 0, ''),
(43, 'yeah great!', 'john_doe', 'sandesh_thapa_1', '2020-04-25 06:21:45', 'no', 'yes', 1, ''),
(44, 'New Post', 'sandesh_thapa_1', 'none', '2020-05-19 06:00:04', 'no', 'no', 1, ''),
(45, 'New post from profile', 'sandesh_thapa_1', 'none', '2020-05-19 06:00:25', 'no', 'no', 1, ''),
(46, 'Great!!', 'sandesh_thapa_1', 'none', '2020-05-19 06:02:53', 'no', 'no', 1, ''),
(47, 'Notification check for profile post', 'sandesh_thapa_1', 'john_doe', '2020-05-20 11:22:19', 'no', 'no', 1, ''),
(48, '<br><iframe width=\'420\' height=\'315\' src=\'https://www.youtube.com/embed/FoZpiI62670\'></iframe><br>', 'nidan_shrestha', 'none', '2020-05-25 10:40:59', 'no', 'no', 1, ''),
(49, 'asdsa', 'sandesh_thapa_1', 'none', '2020-05-28 11:31:39', 'no', 'no', 0, 'assets/images/posts5ecf84fb323c3meme.jpg'),
(50, 'Underside Nepal', 'sandesh_thapa_1', 'none', '2020-05-28 11:34:16', 'no', 'no', 0, 'assets/images/posts5ecf85982cd9dunderside.jpg'),
(51, 'Photo upload from profile', 'sandesh_thapa_1', 'john_doe', '2020-05-29 06:42:41', 'no', 'no', 1, 'assets/images/posts5ed092c0c5b75gnr.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `signup_date` date NOT NULL,
  `profile_pic` varchar(255) NOT NULL,
  `cover_pic` varchar(255) NOT NULL,
  `num_posts` int(11) NOT NULL,
  `num_likes` int(11) NOT NULL,
  `user_closed` varchar(3) NOT NULL,
  `friend_array` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `email`, `password`, `signup_date`, `profile_pic`, `cover_pic`, `num_posts`, `num_likes`, `user_closed`, `friend_array`) VALUES
(1, 'Sandesh', 'Thapa', 'sandesh_thapa', 'sandesh@gmail.com', 'sasasa', '2020-04-01', 'sadas', '', 1, 1, 'no', ''),
(2, 'Sandesh', 'Thapa', 'sandesh_thapa_1', 'st@gmail.com', 'dee3ae5926b1768ea18228ee54281df3', '2020-04-17', 'assets/images/profile_pics/5ea7ba835d9a17.37219352.jfif', 'assets/images/profile_pics/5ea7bb54546266.52489899.jpg', 25, 16, 'no', ',jean_doe,john_doe,manish_khadka,nidan_shrestha,meelan_khadka,'),
(3, 'John', 'Doe', 'john_doe', 'john@gmail.com', '6e0b7076126a29d5dfcbd54835387b7b', '2020-04-17', 'assets/images/profile_pics/defaults/default.jfif', 'assets/images/profile_pics/defaults/cover_pic.jpg', 18, 7, 'no', ',jean_doe,sandesh_thapa_1,meelan_khadka,nidan_shrestha,'),
(4, 'Jean', 'Simpson', 'jean_doe', 'jean@gmail.com', 'a2faca5f819b9b2778e78abb889671ed', '2020-04-17', 'assets/images/profile_pics/defaults/default.png', 'assets/images/profile_pics/defaults/cover_pic.jpg', 7, 4, 'no', ',john_doe,sandesh_thapa_1,'),
(6, 'Meelan', 'Khadka', 'meelan_khadka', 'meelan@gmail.com', '69c45df34c02fc5b2a0de67f31785cbf', '2020-04-22', 'assets/images/profile_pics/defaults/default.png', 'assets/images/profile_pics/defaults/cover_pic.jpg', 0, 0, 'no', ',john_doe,nidan_shrestha,sandesh_thapa_1,'),
(7, 'Manish', 'Khadka', 'manish_khadka', 'manish@gmail.com', '59c95189ac895fcc1c6e1c38d067e244', '2020-05-19', 'assets/images/profile_pics/defaults/default.png', 'assets/images/profile_pics/defaults/cover_pic.jpg', 0, 0, 'no', ',sandesh_thapa_1,'),
(8, 'Nidan', 'Shrestha', 'nidan_shrestha', 'nidan@gmail.com', '097150311ddddfafffb347a0494d30c7', '2020-05-19', 'assets/images/profile_pics/defaults/default.png', 'assets/images/profile_pics/defaults/cover_pic.jpg', 1, 1, 'no', ',sandesh_thapa_1,meelan_khadka,john_doe,');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `friend_requests`
--
ALTER TABLE `friend_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `friend_requests`
--
ALTER TABLE `friend_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
